**RCOS – Regenerative Community Operating System**

# Lernprotokoll

- **Generiert:** 2026-11-06
- **Quelle (aktuelle Version):** [https://rcos.ecohubs.community/de/articles/rcos-templates/layer-6/learning-log](https://rcos.ecohubs.community/de/articles/rcos-templates/layer-6/learning-log)
- **Alle RCOS-Vorlagen:** [https://rcos.ecohubs.community/de/articles/rcos-templates](https://rcos.ecohubs.community/de/articles/rcos-templates)

---
- **Schicht:** 6 — Evolution & Anpassung
- **Status:** Vorlage — an deine Gemeinschaft anpassen; wird aktualisiert, wenn lernrelevante Ereignisse eintreten
- **RCOS-Referenz:** [§8.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-6-evolution-adaptation#8.4), [§8.6](https://rcos.ecohubs.community/de/standard/core/0.1/layer-6-evolution-adaptation#8.6)

> Dokumentiert größere Fehler, Anpassungen, Rücknahmen und systemische Erkenntnisse. Wiederkehrende Fehlermuster müssen eine strukturelle Überprüfung auslösen, keine individuelle Schuldzuweisung. Einträge werden vorangestellt (neueste zuerst).

---

## Was ein lernrelevantes Ereignis ausmacht

*RCOS-Klauseln: [8.4.1](https://rcos.ecohubs.community/de/standard/core/0.1/layer-6-evolution-adaptation#8.4.1), [8.4.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-6-evolution-adaptation#8.4.4), [8.6.5](https://rcos.ecohubs.community/de/standard/core/0.1/layer-6-evolution-adaptation#8.6.5), [8.7.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-6-evolution-adaptation#8.7.4)*

Ein Eintrag MUSS erstellt werden, wenn eines der folgenden Ereignisse eintritt:

- _<Eine Governance-Entscheidung wird rückgängig gemacht, zurückgenommen oder steht im Widerspruch zu einer anderen verabschiedeten Regel.>_
- _<Ein Experiment wird abgeschlossen (Erfolg, Misserfolg oder vorzeitiger Abbruch).>_
- _<Ein Konflikt eskaliert bis zur Governance-Stufe der Konfliktlösungsleiter.>_
- _<Ein strukturelles oder systemisches Versagen wird identifiziert, das Schaden, Verwirrung oder wiederholten Prozesszusammenbruch verursacht hat.>_
- _<Eine wesentliche Anpassung der Gemeinschaftsabläufe wird verabschiedet, die die Funktionsweise einer Schicht erheblich verändert.>_
- _<Ein Beinahe-Vorfall: eine Situation, die erheblichen Schaden hätte verursachen können, aber rechtzeitig erkannt wurde.>_
- _<Jedes Ereignis, das die Gemeinschaft gemeinsam als lernwürdig einstuft.>_

_<Kleinere betriebliche Anpassungen, Routineentscheidungen und individuelle Probleme, die in den frühen Stufen der Konfliktlösungsleiter vollständig gelöst werden, erfordern keinen Eintrag im Lernprotokoll.>_

**Verantwortlichkeit:** _<Rolle, die dafür verantwortlich ist, dass Einträge erstellt und gepflegt werden.>_

**Zusammenfassungsrhythmus:** _<Das Lernprotokoll wird beim Reflexions- & Lerntreffen überprüft; die benannte Rolle bereitet eine kurze Zusammenfassung der Einträge seit der letzten Überprüfung vor und weist auf wiederkehrende Muster hin.>_

---

_Noch keine Einträge. Der erste Eintrag wird hinzugefügt, wenn das erste lernrelevante Ereignis eintritt._

---

## Eintragsformat

*RCOS-Klauseln: [8.4.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-6-evolution-adaptation#8.4.2), [8.4.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-6-evolution-adaptation#8.4.3), [8.6.5](https://rcos.ecohubs.community/de/standard/core/0.1/layer-6-evolution-adaptation#8.6.5)*

```markdown
## <JJJJ-MM-TT> — <Kurztitel>

- **Auslöser:** <Was ist passiert, das diesen Eintrag veranlasst hat>
- **Betroffene Schichten/Artefakte:** <z. B. Schicht 2 — Governance-Protokoll>
- **Was geschehen ist:** <Kurze Beschreibung>
- **Signale, die zum Handeln geführt haben:** <Woran das Problem sichtbar wurde>
- **Was geändert oder versucht wurde:** <Entscheidung, Experiment oder Regeländerung>
- **Ergebnis:** <Resultat nach Überprüfung, falls bekannt>
- **Verantwortliche*r für Nachverfolgung und Frist:** <Name / Rolle und Datum, oder „keine">
```
