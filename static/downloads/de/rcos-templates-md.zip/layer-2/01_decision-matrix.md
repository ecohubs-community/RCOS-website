**RCOS – Regenerative Community Operating System**

# Entscheidungsmatrix

- **Generiert:** 2026-11-06
- **Quelle (aktuelle Version):** [https://rcos.ecohubs.community/de/articles/rcos-templates/layer-2/decision-matrix](https://rcos.ecohubs.community/de/articles/rcos-templates/layer-2/decision-matrix)
- **Alle RCOS-Vorlagen:** [https://rcos.ecohubs.community/de/articles/rcos-templates](https://rcos.ecohubs.community/de/articles/rcos-templates)

---
- **Schicht:** 2 — Governance & Entscheidungslogik
- **Status:** Vorlage — an deine Gemeinschaft anpassen
- **RCOS-Referenz:** [§4.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.2), [§4.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.4), [§4.7](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.7)

> Ordnet jeden Entscheidungstyp und -bereich einer autorisierten Rolle oder einem Gremium, einem Mechanismus, einer Schwelle und einem Eskalationspfad zu. Entscheidungen, die außerhalb dieser Matrix getroffen werden, gelten als ungültig.

---

## Abstimmungsgrundsätze

*RCOS-Klauseln: [4.2.1](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.2.1), [4.2.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.2.2), [4.2.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.2.3), [4.2.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.2.4)*

- **Abstimmungsplattform:** _<z. B. Snapshot, Loomio, Konsens in Präsenz.>_
- **Operative Schwelle:** _<z. B. keine Abstimmung erforderlich — delegiert an die zuständige operative Rolleninhaberin laut Rollenregister.>_
- **Strategische Schwelle:** _<z. B. einfache Mehrheit (>50 %); mindestens X Tage Beratungszeit.>_
- **Konstitutionelle Schwelle:** _<z. B. Supermehrheit (≥⅔); mindestens Y Tage Beratungszeit; Z Tage Ratifizierungszeitraum.>_
- **Stimmengleichheit:** _<z. B. Vorschlag scheitert; Status quo bleibt bestehen.>_
- **Erneute Abstimmung:** _<z. B. jedes Vollmitglied kann mit einem schriftlich begründeten Einwand, der eine während der Beratung nicht behandelte Erwägung benennt, eine erneute Abstimmung auslösen.>_
- **Begründeter Einwand:** _<Definiere, was als begründeter Einwand gilt — nenne eine konkrete Erwägung, die während der Beratung nicht vorgebracht wurde; allgemeine Ablehnung genügt nicht.>_
- **Delegiertes Ausgabenlimit:** _<z. B. 0 €; oder definiere eine Schwelle, unterhalb derer delegierte Ausgaben zulässig sind.>_
- _<Weitere Abstimmungsgrundsätze, die deine Gemeinschaft festlegen möchte.>_

---

## Matrix

*RCOS-Klauseln: [4.4.1](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.4.1), [4.4.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.4.2), [4.4.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.4.3), [4.4.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.4.4)*

| Entscheidungsbereich | Entscheidungstyp | Autorisiertes Gremium | Teilnahmeberechtigte | Mechanismus | Schwelle | Blockade- / Vetobedingungen | Eskalation |
|---|---|---|---|---|---|---|---|
| _<z. B. Mitgliedsaufnahme>_ | _<Operativ / Strategisch / Konstitutionell>_ | _<Rolle oder Gremium>_ | _<wer teilnimmt>_ | _<Abstimmung / delegiert>_ | _<Schwelle>_ | _<Blockadebedingungen>_ | _<Eskalationspfad>_ |
| _<z. B. Finanzausgaben — klein>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ |
| _<z. B. Finanzausgaben — groß>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ |
| _<z. B. Änderungen an Governance-Regeln>_ | _<Konstitutionell>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ |
| _<z. B. Änderungen am Hauptzweck / an Invarianten>_ | _<Konstitutionell>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ |

> **Operative Rolleninhaber:** Jede operative Entscheidung wird von der benannten Rolleninhaberin ausgeführt, die für den jeweiligen Bereich zuständig ist, und zwar innerhalb ihres definierten Zuständigkeitsbereichs gemäß dem Rollenregister (Schicht 5). Wenn eine Entscheidung mehrere Bereiche betrifft, handelt jede Rolleninhaberin innerhalb ihres eigenen Zuständigkeitsbereichs.

## Definitionen der Entscheidungstypen

*RCOS-Klauseln: [4.1.1](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.1.1), [4.1.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.1.2), [4.1.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.1.3), [4.1.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.1.4), [4.1.5](https://rcos.ecohubs.community/de/standard/core/0.1/layer-2-governance-decision-logic#4.1.5)*

- **Operativ** — _<Tagesgeschäft innerhalb bestehender Regeln; wird von der zuständigen Rolleninhaberin ohne Abstimmung ausgeführt.>_
- **Strategisch** — _<langfristige Ausrichtung, bedeutende Ressourcenzuweisung, Schaffung/Abschaffung wesentlicher Strukturen; erfordert eine Abstimmung der Vollmitglieder mit definiertem Beratungszeitraum.>_
- **Konstitutionell** — _<Änderungen an Schicht 0 (Zweck, Geltungsbereich, Invarianten) oder am Governance-System selbst; erfordert eine Abstimmung der Vollmitglieder, Supermehrheit und einen Ratifizierungszeitraum.>_

> Wenn eine Entscheidung nicht eindeutig klassifiziert werden kann, wird standardmäßig der Typ mit höherer Auswirkung angewandt.

---

## Ratifizierungsprotokoll

- **Angenommen am:** <JJJJ-MM-TT>
- **Entscheidungstyp:** Konstitutionell
- **Version:** <Version>
- **Entscheidungsprotokoll:** <Link zum Entscheidungsprotokoll>
