**RCOS – Regenerative Community Operating System**

# Sitzungsvorlagen

- **Generiert:** 2026-11-06
- **Quelle (aktuelle Version):** [https://rcos.ecohubs.community/de/articles/rcos-templates/layer-5/meeting-templates](https://rcos.ecohubs.community/de/articles/rcos-templates/layer-5/meeting-templates)
- **Alle RCOS-Vorlagen:** [https://rcos.ecohubs.community/de/articles/rcos-templates](https://rcos.ecohubs.community/de/articles/rcos-templates)

---
- **Schicht:** 5 — Betrieb & Koordination
- **Status:** Vorlage — an eure Gemeinschaft anpassen
- **RCOS-Referenz:** [§7.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2), [§7.6](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.6)

> Sitzungsvorlagen legen Zweck, Entscheidungsbereich, Beschlussfähigkeit und Struktur jedes Sitzungstyps fest. Eine Sitzung ohne festgelegte Vorlage wird mit der Zeit Befugnisse ansammeln, die sie nicht haben sollte. Passt diese Vorlagen an und fügt Sitzungstypen hinzu oder entfernt sie, wie es eure Gemeinschaft braucht.

---

## Sitzungstyp: Operativ

*RCOS-Klauseln: [7.2.1](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.1), [7.2.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.2), [7.2.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.3), [7.2.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.4), [7.6.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.6.4)*

- **Zweck:** _<laufende Arbeit prüfen, Aufgaben koordinieren, Hindernisse sichtbar machen, operative Entscheidungen treffen.>_
- **Entscheidungsbereich:** Nur operative Entscheidungen — keine strategischen oder konstitutionellen Entscheidungen.
- **Erforderliche Teilnehmende:** _<wer eingeladen ist; Mindest-Quorum.>_
- **Optionale Teilnehmende:** _<wer auf Einladung teilnehmen darf.>_
- **Rhythmus:** _<wöchentlich / zweiwöchentlich / monatlich.>_
- **Zeitlimit:** _<z. B. maximal 90 Minuten.>_
- **Moderation:** _<Moderationsrolle; Vertretungsregel.>_

### Agenda-Struktur

1. **Check-in** _<Dauer>_
2. **Offene Aufgaben prüfen** _<Dauer>_
3. **Rollen- und Bereichs-Updates** _<Dauer>_
4. **Aktuelle Tagesordnungspunkte** _<Dauer>_
5. **Operative Entscheidungen** _<Dauer>_
6. **Nächste Schritte und Verantwortliche** _<Dauer>_
7. **Check-out** _<Dauer; optional>_

### Notizen und Protokoll

- **Datum:**
- **Moderation:**
- **Anwesende:**
- **Notizen:**

### Entscheidungsprotokoll (falls zutreffend)

- **Entscheidungstyp:** Operativ
- **Befugnis:** _<Rolleninhaber:in laut Entscheidungsmatrix>_
- **Mechanismus / Schwelle:** Delegierte Befugnis
- **Ergebnis:** _<was entschieden wurde>_
- **Gültig ab:**
- **Abgelegt unter:** _<Ablageort>_

---

## Sitzungstyp: Governance

*RCOS-Klauseln: [7.2.1](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.1), [7.2.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.2), [7.2.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.3), [7.6.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.6.4)*

- **Zweck:** Beratung über einen aktiven Vorschlag während seiner Beratungsphase.
- **Entscheidungsbereich:** Nur Beratung — die verbindliche Entscheidung erfolgt über den Governance-Prozess gemäß der Entscheidungsmatrix.
- **Erforderliche Teilnehmende:** _<alle Vollmitglieder eingeladen; Antragsteller:in muss anwesend sein.>_
- **Optionale Teilnehmende:** _<wer beobachten darf.>_
- **Rhythmus:** _<nach Bedarf während der Beratungsphasen.>_
- **Zeitlimit:** _<z. B. maximal 60 Minuten.>_
- **Moderation:** _<Moderationsrolle.>_

### Agenda-Struktur

1. **Check-in** _<Dauer>_
2. **Zusammenfassung des Vorschlags** _<Dauer — Antragsteller:in stellt den Vorschlag vor: was sich ändert, warum, und welche Alternativen erwogen wurden.>_
3. **Verständnisfragen** _<Dauer — nur Sachfragen; noch keine Positionierung.>_
4. **Offene Beratung** _<Dauer.>_
5. **Zusammenfassung der Positionen und nächste Schritte** _<Dauer — Moderation fasst zusammen; bestätigt den Abstimmungszeitplan.>_

### Notizen und Protokoll

- **Datum:**
- **Moderation:**
- **Anwesende:**
- **Notizen:**

### Entscheidungsprotokoll

- **Vorschlags-Referenz:** _<Link zum Vorschlag>_
- **Entscheidungstyp:** _<Strategisch / Konstitutionell>_
- **Befugnis:** Vollmitglieder (kollektiv)
- **Mechanismus / Schwelle:** _<Abstimmungsmechanismus + Schwelle>_
- **Ergebnis:** _<Angenommen / Abgelehnt / Vertagt>_
- **Gültig ab:**
- **Abstimmungs-Link:**

---

## Sitzungstyp: Koordination & Abstimmung

*RCOS-Klauseln: [7.2.1](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.1), [7.2.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.2), [7.2.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.3), [7.6.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.6.4)*

- **Zweck:** Arbeit über Rollen und Initiativen hinweg synchronisieren; Abhängigkeiten und Hindernisse sichtbar machen; Prioritäten abstimmen.
- **Entscheidungsbereich:** Nur operative Entscheidungen.
- **Erforderliche Teilnehmende:** _<Rolleninhaber:innen mit aktiven Initiativen.>_
- **Optionale Teilnehmende:** _<alle Vollmitglieder willkommen.>_
- **Rhythmus:** _<monatlich oder nach Bedarf.>_
- **Zeitlimit:** _<z. B. 60 Minuten.>_
- **Moderation:** _<Moderator:in; Vertretungsregel.>_

### Agenda-Struktur

1. **Check-in** _<Dauer>_
2. **Status-Updates der Initiativen** _<Dauer>_
3. **Hindernisse und Abhängigkeiten** _<Dauer>_
4. **Nächste Schritte** _<Dauer>_

### Notizen und Protokoll

- **Datum:**
- **Moderation:**
- **Anwesende:**
- **Notizen:**

---

## Sitzungstyp: Reflexion & Lernen

*RCOS-Klauseln: [7.2.1](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.1), [7.2.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.2), [7.2.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.3), [7.6.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.6.4)*

- **Zweck:** Erfahrungen auswerten, Muster erkennen, Erkenntnisse festhalten, Einsichten ins Framework zurückspielen.
- **Entscheidungsbereich:** Kann Änderungsvorschläge hervorbringen; keine direkte Entscheidungsbefugnis, sofern nicht in der Entscheidungsmatrix festgelegt.
- **Erforderliche Teilnehmende:** _<alle Vollmitglieder eingeladen.>_
- **Rhythmus:** _<vierteljährlich.>_
- **Zeitlimit:** _<z. B. maximal 90 Minuten.>_
- **Moderation:** _<Moderationsrolle.>_

### Agenda-Struktur

1. **Check-in** _<Dauer>_
2. **Highlights des Zeitraums** _<Dauer>_
3. **Was gut lief** _<Dauer>_
4. **Was nicht lief / was wir anders machen würden** _<Dauer; kein Schuldzuweisen, Fokus auf Muster.>_
5. **Erkenntnisse für die Zukunft** _<Dauer; Einträge für das Lernprotokoll identifizieren.>_
6. **Aktualisierung von Lernprotokoll und zukünftigen Vorschlägen** _<Dauer.>_
7. **Check-out** _<Dauer>_

### Notizen und Protokoll

- **Datum:**
- **Moderation:**
- **Anwesende:**
- **Notizen:**
- **Ausgelöste Lernprotokoll-Einträge:** _<Liste oder „keine">_
- **Hinzugefügte zukünftige Vorschläge:** _<Liste oder „keine">_

---

## Sitzungstyp: Konfliktbearbeitung

*RCOS-Klauseln: [7.2.1](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.1), [7.2.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.2), [7.2.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.2.3), [7.6.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-5-operations-coordination#7.6.4); siehe auch Schicht 4 — [Konfliktlösungsleiter](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.2)*

- **Zweck:** Lösung auf einer definierten Stufe der Konfliktlösungsleiter moderieren (Stufen 2–4).
- **Entscheidungsbereich:** Erarbeitet Reparaturpläne, Vereinbarungen oder Eskalationsentscheidungen; verbindliche Ergebnisse erfordern die in der Konfliktlösungsleiter und der Entscheidungsmatrix festgelegte Befugnis.
- **Erforderliche Teilnehmende:** Konfliktparteien; zugewiesene:r Moderator:in (gemäß den Auswahlregeln der Konfliktlösungsleiter).
- **Optionale Teilnehmende:** Eine Vertrauensperson, mit schriftlicher gegenseitiger Zustimmung aller Parteien.
- **Rhythmus:** Nach Bedarf; ausgelöst durch Eingangsverfahren.
- **Zeitlimit:** _<typischerweise 60–90 Minuten; Moderator:in kann verlängern.>_
- **Moderation:** Auswahl gemäß Konfliktlösungsleiter (Schicht 4) — nicht von den Parteien selbst gewählt.

> **Datenschutzhinweis:** Aufzeichnungen aus diesem Sitzungstyp unterliegen den Datenschutz- und Informationszugangsregelungen der Konfliktlösungsleiter (Schicht 4). Sie werden standardmäßig nicht im allgemeinen Mitgliederprotokoll veröffentlicht.

### Agenda-Struktur

1. **Eröffnung und Grundregeln** _<Dauer; Einverständnis, Vertraulichkeit, Vergeltungsschutz, Pausenrecht.>_
2. **Jede Partei schildert ihre Perspektive** _<ohne Unterbrechung; gleiche Redezeit.>_
3. **Prüfung des gemeinsamen Verständnisses** _<Dauer.>_
4. **Bedürfnisse und Bitten** _<Dauer.>_
5. **Reparatur- oder Einigungsoptionen** _<Dauer.>_
6. **Entscheidung oder nächster Schritt** _<Dauer.>_
7. **Dokumentation** _<Dauer; Protokoll gemäß Datenschutzregeln der Schicht 4.>_

### Protokollformat

> Dieses Protokoll ist vertraulich. Der Zugang ist gemäß der Konfliktlösungsleiter (Schicht 4) eingeschränkt.

- **Datum:**
- **Moderation:**
- **Anwesende Parteien:**
- **Leiterstufe:**
- **Konfliktklasse:**
- **Ergebnis:** _<Einigung erzielt / Eskalation auf nächste Stufe / Vertagt>_
- **Vereinbarte Maßnahmen (falls vorhanden):**
- **Eskalationsziel (falls zutreffend):**
- **Zugang:** Nur Parteien und Moderator:in; Offenlegung gegenüber Vollmitgliedern nur bei Eskalation auf die Governance-Stufe.

---

## Ratifizierungsprotokoll

- **Angenommen:** <JJJJ-MM-TT>
- **Entscheidungstyp:** Strategisch
- **Version:** <Version>
- **Entscheidungsprotokoll:** <Link zum Entscheidungsprotokoll>
