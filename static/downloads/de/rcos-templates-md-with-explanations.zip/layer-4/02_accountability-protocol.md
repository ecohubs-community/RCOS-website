**RCOS – Regenerative Community Operating System**

# Rechenschaftsprotokoll

- **Generiert:** 2026-11-02
- **Quelle (aktuelle Version):** [https://rcos.ecohubs.community/de/articles/rcos-templates/layer-4/accountability-protocol](https://rcos.ecohubs.community/de/articles/rcos-templates/layer-4/accountability-protocol)
- **Alle RCOS-Vorlagen:** [https://rcos.ecohubs.community/de/articles/rcos-templates](https://rcos.ecohubs.community/de/articles/rcos-templates)

---
- **Ebene:** 4 — Konflikt, Wiedergutmachung & Rechenschaft
- **Status:** Vorlage — an deine Gemeinschaft anpassen
- **RCOS-Referenz:** [§6.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4), [§6.5](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.5)

---

## Auslöser

*RCOS-Klauseln: [6.4.1](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4.1), [6.5.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.5.4)*

<details data-kind="rationale">
<summary>Warum festlegen, was eine Rechenschaftsprüfung auslöst?</summary>

Wenn Rechenschaftsprüfungen nur stattfinden, wenn jemand sich stark genug fühlt, sie durchzusetzen, werden sie politisch. Die genauen Auslöser zu benennen — Inaktivität, Verstoß, Invarianten-Verletzung, Verweisung — bedeutet, dass der Prozess bei einer Bedingung ansetzt, die jeder überprüfen kann, und nicht bei einem Urteil über eine Person.

</details>

<details data-kind="instructions">
<summary>Wie du das ausfüllst</summary>

Liste die konkreten, überprüfbaren Auslöser auf, die eine Rechenschaftsprüfung einleiten. Jeder Auslöser sollte anhand von Aufzeichnungen oder einer direkten Verweisung nachvollziehbar sein.

</details>

Eine Rechenschaftsprüfung wird eingeleitet, wenn:

1. _<Ein Mitglied in X aufeinanderfolgenden Monaten keinen anerkannten Beitrag geleistet hat.>_
2. _<Ein Mitglied gegen eine Pflicht aus der Mitgliedschaftsvereinbarung verstoßen hat.>_
3. _<Ein Mitglied eine Identitäts-Einschränkung oder Invariante der Schicht 0 verletzt hat.>_
4. _<Eine Verweisung aus der Konfliktlösungsleiter (Stufe 3 oder höher) erfolgt ist.>_

## Untersuchung und Überprüfung

*RCOS-Klauseln: [6.4.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4.2), [6.4.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4.3), [6.4.6](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4.6), [6.5.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.5.4)*

<details data-kind="rationale">
<summary>Warum die Reaktion nach Schweregrad abstufen?</summary>

Einen versäumten Beitrag genauso zu behandeln wie eine Invarianten-Verletzung erdrückt entweder leichte Fälle mit schwerem Verfahren oder lässt schwere Fälle mit einem privaten Gespräch durchrutschen. Abgestufte Wege — sanftes Nachfragen, mittlere schriftliche Benachrichtigung, direkte Eskalation bei schweren Verstößen — passen das Gewicht der Reaktion an das Gewicht des Verstoßes an und machen Wiedergutmachung dort zum Standard, wo Wiedergutmachung noch möglich ist.

</details>

<details data-kind="instructions">
<summary>Wie du das ausfüllst</summary>

Definiere sanfte (Inaktivität), mittlere (Pflichtverletzung) und schwere (Invarianten-Verletzung, Sicherheit) Wege. Gib an, wer den Prozess einleitet, welche Reaktionsfrist gilt und wie die Eskalation jeweils verläuft.

</details>

> **Leitlinie zur Verstoßschwere:** _<mittel = Nichteinhaltung einer Pflicht aus der Mitgliedschaftsvereinbarung, die weder die Sicherheit von Mitgliedern noch die Integrität der Gemeinschaft gefährdet; schwer = Verletzung einer Invariante der Schicht 0, glaubwürdige Sicherheitsbedenken, anhaltend bösgläubiges Verhalten.>_

- **Inaktivität (leichter Verstoß):** _<Wer kontaktiert das Mitglied; Reaktionsfrist; mögliche Ergebnisse.>_
- **Pflichtverletzung (mittel):** _<Schriftliche Benachrichtigung; Reaktionsfrist; Lösungs- / Eskalationswege.>_
- **Schwerer Verstoß / Invarianten-Verletzung:** _<Direkte Eskalation an die entsprechende Stufe der Konfliktlösungsleiter.>_

## Verfahrensgarantien

*RCOS-Klauseln: [6.4.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4.2), [6.4.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4.4), [6.5.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.5.4)*

<details data-kind="rationale">
<summary>Warum Benachrichtigungs-, Antwort- und Widerspruchsrechte ausformulieren?</summary>

Rechenschaft ohne faires Verfahren ist nur Bestrafung mit Papierkram. Ein Mitglied, das mit einer Sanktion konfrontiert ist, muss das Anliegen kennen, echte Zeit zum Antworten haben und eine Stelle zum Einlegen eines Widerspruchs haben — andernfalls ist das Wort des Entscheidungsgremiums standardmäßig endgültig, was Macht genau dort konzentriert, wo sie sich nicht konzentrieren sollte.

</details>

<details data-kind="instructions">
<summary>Wie du das ausfüllst</summary>

Lege das Recht auf schriftliche Benachrichtigung, eine Mindest-Reaktionsfrist und einen expliziten Widerspruchsweg an die Vollmitglieder fest.

</details>

- **Recht auf Benachrichtigung:** _<Das Mitglied wird schriftlich über das Anliegen informiert, bevor eine Überprüfung oder Sanktion beginnt.>_
- **Recht auf Antwort:** _<Mindest-Reaktionsfrist — z. B. 30 Tage.>_
- **Recht auf Widerspruch:** _<Jede Entscheidung kann über den Governance-Prozess angefochten werden (strategische Abstimmung).>_

## Schutz vor Vergeltung

*RCOS-Klauseln: [6.3.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.3.2)*

<details data-kind="rationale">
<summary>Warum Beteiligte explizit schützen?</summary>

Wenn das Äußern eines Anliegens oder das Bereitstellen von Informationen ein Mitglied Ansehen, Beziehungen oder Zugang kosten kann, werden die Menschen schweigen und das Rechenschaftssystem bricht in der Praxis zusammen. Vergeltung selbst als Auslöser zu benennen, macht die Kosten der Unterdrückung höher als die Kosten der Meldung.

</details>

<details data-kind="instructions">
<summary>Wie du das ausfüllst</summary>

Halte fest, dass Vergeltung gegen jedes Mitglied, das ein Anliegen erhebt, an einem Rechenschaftsprozess teilnimmt oder Informationen dazu beisteuert, selbst ein Auslöser für eine Rechenschaftsprüfung ist.

</details>

_<Vergeltung gegen ein Mitglied für die Teilnahme an irgendeinem Teil dieses Prozesses ist selbst ein Auslöser für eine Rechenschaftsprüfung.>_

## Sanktions- und Wiedergutmachungsoptionen

*RCOS-Klauseln: [6.4.1](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4.1), [6.4.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4.2), [6.4.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4.3), [6.4.5](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4.5), [6.4.6](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4.6), [6.5.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.5.4), [6.6.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.6.3)*

<details data-kind="rationale">
<summary>Warum den Katalog der Sanktionen vorab festlegen?</summary>

Ad-hoc-Sanktionen, die mitten im Prozess erfunden werden, spiegeln wider, wer am lautesten im Raum ist, nicht was der Verstoß rechtfertigt. Ein fester Katalog — mit Voraussetzungen, befugtem Gremium und Widerspruchsweg für jede Sanktion — hält die Reaktionen verhältnismäßig, verhindert, dass informeller Ausschluss zur Standardstrafe wird, und macht deutlich, wenn eine Sanktion außerhalb des Zuständigkeitsbereichs des anwendenden Gremiums liegt.

</details>

<details data-kind="instructions">
<summary>Wie du das ausfüllst</summary>

Definiere für jeden Sanktionstyp die Voraussetzungen, das befugte Gremium und den Widerspruchsweg. Auf Wiedergutmachung ausgerichtete Maßnahmen sollten der Standard sein; strafende Maßnahmen sind sicherheitskritischen oder ungelösten Verstößen vorbehalten.

</details>

> Auf Wiedergutmachung ausgerichtete Maßnahmen werden gegenüber strafenden bevorzugt, außer in sicherheitskritischen Fällen.
> Sanktionen müssen verhältnismäßig, wo anwendbar zeitlich begrenzt, dokumentiert und niemals durch informellen Ausschluss oder sozialen Druck verhängt werden.

| Typ | Voraussetzungen | Befugtes Gremium | Anfechtbar? |
|---|---|---|---|
| _<Persönliches Nachfragen / Erinnerung>_ | _<Inaktivität oder geringfügiger Verstoß>_ | _<Rolle>_ | _<ja>_ |
| _<Schriftliche Verwarnung>_ | _<Ungelöste Pflichtverletzung nach Nachfragen>_ | _<Rolle>_ | _<ja>_ |
| _<Vorübergehende Zugangsbeschränkung>_ | _<Sicherheitskritische Situation; Überprüfungsfenster>_ | _<Rolle>_ | _<ja>_ |
| _<Erzwungener Austritt>_ | _<Schwerer oder ungelöster Verstoß, oder Entscheidung der Vollmitglieder>_ | _<Vollmitglieder>_ | _<ja — erneute Abstimmung>_ |

## Bedingungen für die Wiederherstellung von Rechten

*RCOS-Klauseln: [6.4.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4.4)*

<details data-kind="rationale">
<summary>Warum Bedingungen für die Wiederherstellung explizit festlegen?</summary>

Wenn es keinen definierten Weg zurück gibt, wird jede Sanktion faktisch dauerhaft und jeder Austritt zu einer lebenslangen Strafe. Explizite Bedingungen für die Wiederherstellung signalisieren, dass Rechenschaft auf Wiedergutmachung abzielt, wo Wiedergutmachung möglich ist, und sie verhindern nachträgliches Gatekeeping darüber, ob jemand „wirklich" willkommen zurück ist.

</details>

<details data-kind="instructions">
<summary>Wie du das ausfüllst</summary>

Lege für jede Sanktionsklasse den Weg zur Wiederherstellung der Rechte fest — erneute Bewerbung nach freiwilligem Austritt, Sperrfrist für erneute Bewerbung nach erzwungenem Austritt, Wiederherstellung nach vorübergehender Einschränkung.

</details>

- **Nach freiwilligem Austritt:** _<Erneute Bewerbung über das Onboarding-Protokoll; keine automatische Wiederherstellung.>_
- **Nach erzwungenem Austritt:** _<Mindest-Sperrfrist für erneute Bewerbung; das reguläre Aufnahmeverfahren gilt.>_
- **Nach vorübergehender Zugangsbeschränkung:** _<Rechte werden nach Bestätigung der Lösung innerhalb des Überprüfungsfensters wiederhergestellt.>_

## Abstimmung mit Schicht 1

*RCOS-Klauseln: [6.4.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-4-conflict-repair-accountability#6.4.4)*

<details data-kind="rationale">
<summary>Warum das mit dem Austritts- und Trennungsprotokoll verknüpfen?</summary>

Austrittsregeln sind aus gutem Grund in Schicht 1 angesiedelt — sie regeln, wer Mitglied ist und wer nicht. Wenn Rechenschaftsmaßnahmen ihren eigenen parallelen Austrittsweg schaffen würden, gäbe es zwei Regelwerke, zwei Sätze von Aufzeichnungen und ein Schlupfloch, um das faire Verfahren zu umgehen. Ein einziges kanonisches Austrittsprotokoll schließt diese Lücke.

</details>

<details data-kind="instructions">
<summary>Wie du das ausfüllst</summary>

Halte fest, dass alle erzwungenen Austritte und vorübergehenden Zugangsbeschränkungen dem Austritts- und Trennungsprotokoll (Schicht 1) folgen, und stelle klar, dass eine vorübergehende Einschränkung keinen Austritt darstellt.

</details>

_<Alle erzwungenen Austritte und vorübergehenden Zugangsbeschränkungen folgen dem Austritts- und Trennungsprotokoll (Schicht 1). Eine vorübergehende Zugangsbeschränkung stellt keinen Austritt dar und löst keine Sperrfrist für eine erneute Bewerbung aus, es sei denn, ein erzwungener Austritt wird anschließend von den Vollmitgliedern beschlossen.>_

---

## Ratifizierungsprotokoll

- **Angenommen:** <JJJJ-MM-TT>
- **Entscheidungstyp:** Strategisch
- **Version:** <Version>
- **Entscheidungsprotokoll:** <Link zum Entscheidungsprotokoll>
