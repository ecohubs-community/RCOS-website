**RCOS – Regenerative Community Operating System**

# Invariantenregister

- **Generiert:** 2026-11-06
- **Quelle (aktuelle Version):** [https://rcos.ecohubs.community/de/articles/rcos-templates/layer-0/invariants-register](https://rcos.ecohubs.community/de/articles/rcos-templates/layer-0/invariants-register)
- **Alle RCOS-Vorlagen:** [https://rcos.ecohubs.community/de/articles/rcos-templates](https://rcos.ecohubs.community/de/articles/rcos-templates)

---
- **Schicht:** 0 — Identität & Geltungsbereich
- **Status:** Vorlage — für deine Gemeinschaft anpassen
- **RCOS-Referenz:** [§2.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-0-identity-scope#2.3), [§2.5](https://rcos.ecohubs.community/de/standard/core/0.1/layer-0-identity-scope#2.5)

> Invarianten sind Rahmenbedingungen, die DÜRFEN NICHT verletzt werden, solange sie in Kraft sind. Keine Entscheidung, Rolle, Prozess oder Notfallmaßnahme darf eine Invariante außer Kraft setzen. Entsteht ein Konflikt zwischen einer Invariante und einer anderen Regel, hat die Invariante Vorrang.

---

## Aktive Invarianten

*RCOS-Klauseln: [2.3.1](https://rcos.ecohubs.community/de/standard/core/0.1/layer-0-identity-scope#2.3.1), [2.3.2](https://rcos.ecohubs.community/de/standard/core/0.1/layer-0-identity-scope#2.3.2), [2.3.3](https://rcos.ecohubs.community/de/standard/core/0.1/layer-0-identity-scope#2.3.3), [2.3.4](https://rcos.ecohubs.community/de/standard/core/0.1/layer-0-identity-scope#2.3.4), [2.3.5](https://rcos.ecohubs.community/de/standard/core/0.1/layer-0-identity-scope#2.3.5), [2.3.6](https://rcos.ecohubs.community/de/standard/core/0.1/layer-0-identity-scope#2.3.6)*

<details data-kind="rationale">
<summary>Warum können Invarianten nicht außer Kraft gesetzt werden?</summary>

Invarianten sind der harte Boden des Systems — Dinge, die auch unter Druck, in Notfällen oder bei einer Mehrheitsentscheidung gelten müssen. Wenn eine Entscheidung, eine Rolle oder eine Krisenmaßnahme sie außer Kraft setzen könnte, wären sie keine Rahmenbedingungen mehr, sondern nur noch Präferenzen. Sie explizit aufzulisten und auf allen Schichten zu verankern macht das Governance-System auch unter Stress verlässlich — nicht nur an ruhigen Tagen.

</details>

<details data-kind="instructions">
<summary>So füllst du das aus</summary>

Jede Invariante ist eine harte Rahmenbedingung. Halte sie wenige, spezifisch und absolut — so formuliert, dass jede Verletzung eindeutig erkennbar ist. Häufige Kategorien: Zweckschutz, Rückverfolgbarkeit von Autorität, Austrittsrechte, ideologische Neutralität, Nicht-Extraktion, Sicherheitsvorrang.

</details>

| ID | Invariante | Hinzugefügt | Entscheidungsprotokoll |
|---|---|---|---|
| INV-001 | _<Invariantenaussage, z. B. Der primäre Zweck darf durch keine operative oder strategische Entscheidung, Rolle oder Notfallmaßnahme außer Kraft gesetzt werden.>_ | <JJJJ-MM-TT> | [Link] |
| INV-002 | _<Invariantenaussage, z. B. Autorität muss stets explizit und auf das Governance-System zurückführbar sein — keine Person und keine Rolle darf nicht deklarierte Autorität innehaben oder ausüben.>_ | <JJJJ-MM-TT> | [Link] |
| INV-003 | _<Invariantenaussage, z. B. Der Austritt aus der Gemeinschaft muss stets möglich sein und darf niemals blockiert, bestraft oder über das in Schicht 1 Festgelegte hinaus an Bedingungen geknüpft werden.>_ | <JJJJ-MM-TT> | [Link] |
| INV-004 | _<Invariantenaussage.>_ | <JJJJ-MM-TT> | [Link] |
| INV-005 | _<Invariantenaussage.>_ | <JJJJ-MM-TT> | [Link] |
| INV-006 | _<Invariantenaussage, z. B. Körperliche, psychische und Kindersicherheit haben stets Vorrang vor Teilnahmerechten, Rollenkontinuität und Reputationsbelangen.>_ | <JJJJ-MM-TT> | [Link] |

---

## Ratifizierungsprotokoll

- **Angenommen:** <JJJJ-MM-TT>
- **Entscheidungstyp:** Konstitutionell
- **Version:** <Version>
- **Entscheidungsprotokoll:** <Link zum Entscheidungsprotokoll>
