**RCOS — Système d'Exploitation de Communauté Régénérative**

# Protocole de changement

- **Généré:** 2026-11-06
- **Source (version la plus récente):** [https://rcos.ecohubs.community/fr/articles/rcos-templates/layer-6/change-protocol](https://rcos.ecohubs.community/fr/articles/rcos-templates/layer-6/change-protocol)
- **Tous les modèles RCOS:** [https://rcos.ecohubs.community/fr/articles/rcos-templates](https://rcos.ecohubs.community/fr/articles/rcos-templates)

---
- **Couche :** 6 — Évolution et adaptation
- **Statut :** Modèle — à adapter pour ta communauté
- **Référence RCOS :** [§8.1](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.1), [§8.5](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.5), [§8.6](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.6)

> Définit comment les règles de la communauté changent : comment un changement est proposé, classifié, examiné, adopté ou rejeté, mis en place et annulé — ainsi que les voies étroites pour les changements d'urgence et les expérimentations.

---

## Comment les changements sont proposés

*Clauses RCOS : [8.1.1](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.1.1), [8.1.3](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.1.3), [8.6.3](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.6.3), [8.8.1](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.8.1)*

_<Tout Membre de plein droit peut proposer un changement à tout artefact RCOS. Indique le canal de soumission.>_ Chaque proposition doit inclure :

- _<Résumé du changement.>_
- _<Couches et artefacts concernés (avec liens).>_
- _<Type de décision (Opérationnel / Stratégique / Constitutionnel).>_
- _<Justification.>_
- _<Risques et mesures d'atténuation.>_
- _<Plan de retour en arrière.>_
- _<Date d'entrée en vigueur proposée.>_

## Comment les propositions sont classifiées

*Clauses RCOS : [8.1.2](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.1.2), [8.1.4](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.1.4)*

- **Opérationnel :** _<corrections de formulation, mise en forme, mises à jour mineures de contenu ; aucun vote requis ; exécuté par le rôle responsable dans les limites de sa délégation.>_
- **Stratégique :** _<changements du contenu des Couches 1 à 5 qui affectent les droits des membres, les processus ou les structures.>_
- **Constitutionnel :** _<changements de la Couche 0 (raison d'être, périmètre, invariants) ou du système de gouvernance lui-même (Couche 2).>_

> En cas de doute sur la classification, le type à impact supérieur s'applique par défaut.

## Examen et délibération

*Clauses RCOS : [8.1.2](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.1.2), [8.7.1](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.7.1)*

- **Opérationnel :** _<aucune délibération requise.>_
- **Stratégique :** _<délibération minimale de X jours ; lieu de délibération.>_
- **Constitutionnel :** _<délibération minimale de Y jours ; période de ratification de Z jours après l'adoption du vote.>_

## Adoption et publication

*Clauses RCOS : [8.2.1](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.2.1), [8.2.2](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.2.2), [8.2.5](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.2.5), [8.6.3](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.6.3)*

Lorsqu'une proposition est adoptée :

1. _<Fichier de proposition déplacé vers l'archive des propositions adoptées dans un délai de X jours.>_
2. _<Artefacts concernés mis à jour dans un délai de X jours.>_
3. _<Entrée ajoutée à l'historique des versions.>_
4. _<Champs de statut mis à jour sur les artefacts concernés.>_

## Rejet

*Clauses RCOS : [8.2.2](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.2.2), [8.2.4](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.2.4)*

Lorsqu'une proposition est rejetée :

1. _<Fichier de proposition déplacé vers l'archive des propositions rejetées dans un délai de X jours.>_
2. _<Aucune modification d'artefact effectuée.>_
3. _<Le mécanisme de nouveau vote s'applique si de nouvelles informations émergent (selon la Matrice de décision, Couche 2).>_

## Transition et migration

*Clauses RCOS : [8.5.1](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.5.1), [8.5.2](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.5.2)*

Lorsqu'un changement de règle affecte des rôles, accords ou registres existants :

- _<Les titulaires de rôles existants sont notifiés avant l'entrée en vigueur du changement.>_
- _<Les droits des membres existants ne peuvent pas être réduits sans consentement ou vote constitutionnel.>_
- _<Les registres antérieurs au changement ne sont pas modifiés rétroactivement, sauf si cela fait explicitement partie de la proposition.>_
- _<Une période de transition peut être définie dans la proposition elle-même.>_

## Retour en arrière

*Clauses RCOS : [8.1.5](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.1.5), [8.5.1](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.5.1)*

_<Toute décision adoptée peut être annulée par le même processus que l'original. Tout Membre de plein droit peut déclencher un nouveau vote en soumettant une objection écrite et motivée qui n'a pas été prise en compte lors de la délibération originale. Le retour en arrière utilise le même type de décision que l'original.>_

## Changements d'urgence

*Clauses RCOS : [8.5.3](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.5.3)*

Un changement opérationnel d'urgence peut être effectué par _<rôle>_ uniquement si toutes les conditions suivantes sont réunies :

1. _<Action immédiate requise pour prévenir un préjudice à la sécurité ou une défaillance de plateforme.>_
2. _<Un vote des Membres de plein droit ne peut pas être convoqué à temps.>_
3. _<Le changement ne contrevient pas à un invariant de la Couche 0.>_

Les changements d'urgence doivent être :

- _<Signalés à tous les Membres de plein droit dans un délai de X heures.>_
- _<Examinés lors de la prochaine réunion communautaire.>_
- _<Ratifiés via le type de décision approprié dans un délai de Y jours, ou automatiquement annulés.>_

## Expérimentations

*Clauses RCOS : [8.3.1](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.3.1), [8.3.2](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.3.2), [8.3.3](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.3.3), [8.3.4](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.3.4), [8.3.5](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.3.5), [8.7.3](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-6-evolution-adaptation#8.7.3)*

_<Tout Membre de plein droit peut proposer une expérimentation limitée dans le temps via une décision stratégique. Voir le Modèle d'expérimentation pour les champs obligatoires.>_

- _<Les expérimentations expirent automatiquement à la fin de leur durée définie, sauf renouvellement explicite via une nouvelle proposition.>_
- _<Tous les artefacts affectés par une expérimentation doivent être explicitement étiquetés comme expérimentaux pendant toute la durée.>_
- _<Suspension de sécurité : si une expérimentation introduit un risque crédible pour la sécurité, de la coercition ou un préjudice durable, une suspension d'urgence peut être invoquée conformément aux Changements d'urgence ci-dessus.>_
- _<Les résultats et enseignements sont consignés dans le Journal d'apprentissage.>_

---

## Registre de ratification

- **Adopté :** <AAAA-MM-JJ>
- **Type de décision :** Constitutionnel
- **Version :** <version>
- **Registre de décision :** <lien vers le registre de décision>
