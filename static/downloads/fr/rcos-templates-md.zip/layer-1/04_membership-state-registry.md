**RCOS — Système d'Exploitation de Communauté Régénérative**

# Registre des états de membre

- **Généré:** 2026-11-06
- **Source (version la plus récente):** [https://rcos.ecohubs.community/fr/articles/rcos-templates/layer-1/membership-state-registry](https://rcos.ecohubs.community/fr/articles/rcos-templates/layer-1/membership-state-registry)
- **Tous les modèles RCOS:** [https://rcos.ecohubs.community/fr/articles/rcos-templates](https://rcos.ecohubs.community/fr/articles/rcos-templates)

---
- **Couche :** 1 — Système de membres
- **Statut :** Modèle — à adapter pour ta communauté
- **Référence RCOS :** [§3.1](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-1-membership-system#3.1)

> Répertorie chaque état de membre que reconnaît ta communauté, avec les droits et obligations de chacun et la manière de passer de l'un à l'autre. Chaque personne a exactement un état à la fois.

---

## États de membre définis

*Clauses RCOS : [3.1.1](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-1-membership-system#3.1.1), [3.1.2](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-1-membership-system#3.1.2), [3.1.3](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-1-membership-system#3.1.3), [3.1.4](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-1-membership-system#3.1.4), [3.1.5](https://rcos.ecohubs.community/fr/standard/core/0.1/layer-1-membership-system#3.1.5)*

| État | Droits | Obligations | Condition d'entrée | Condition de sortie |
|---|---|---|---|---|
| _<État 1, par ex. Candidat·e>_ | _<droits>_ | _<obligations>_ | _<entrée>_ | _<sortie>_ |
| _<État 2, par ex. Membre en période d'essai>_ | _<droits>_ | _<obligations>_ | _<entrée>_ | _<sortie>_ |
| _<État 3, par ex. Membre à part entière>_ | _<droits>_ | _<obligations>_ | _<entrée>_ | _<sortie>_ |
| _<État 4, par ex. Membre sorti·e>_ | _<droits>_ | _<obligations>_ | _<entrée>_ | _<sortie>_ |

> Aucune personne ne peut détenir plusieurs états de membre simultanément.
> Aucun droit ni obligation ne peut être assumé en dehors de l'état de membre actuel de la personne.

---

## Procès-verbal de ratification

- **Adopté le :** <AAAA-MM-JJ>
- **Type de décision :** Stratégique
- **Version :** <version>
- **Registre de décision :** <lien vers le registre de décision>
