**RCOS — Sistema Operativo de Comunidad Regenerativa**

# Historial de Versiones

- **Generado:** 2026-11-02
- **Fuente (versión más reciente):** [https://rcos.ecohubs.community/es/articles/rcos-templates/layer-6/version-history](https://rcos.ecohubs.community/es/articles/rcos-templates/layer-6/version-history)
- **Todas las plantillas RCOS:** [https://rcos.ecohubs.community/es/articles/rcos-templates](https://rcos.ecohubs.community/es/articles/rcos-templates)

---
- **Capa:** 6 — Evolución y Adaptación
- **Estado:** Plantilla — adapta para tu comunidad; actualizada con cada cambio adoptado
- **Referencia RCOS:** [§8.2](https://rcos.ecohubs.community/es/standard/core/0.1/layer-6-evolution-adaptation#8.2), [§8.6](https://rcos.ecohubs.community/es/standard/core/0.1/layer-6-evolution-adaptation#8.6)

> El registro legible por humanos y con carácter oficial de todos los cambios adoptados en la implementación RCOS de tu comunidad. La versión actualmente vigente es la entrada más reciente en la parte superior de este archivo. Las reglas sustituidas permanecen accesibles a través del control de versiones.

---

## Formato de Entrada

*Cláusulas RCOS: [8.2.1](https://rcos.ecohubs.community/es/standard/core/0.1/layer-6-evolution-adaptation#8.2.1), [8.2.2](https://rcos.ecohubs.community/es/standard/core/0.1/layer-6-evolution-adaptation#8.2.2), [8.2.3](https://rcos.ecohubs.community/es/standard/core/0.1/layer-6-evolution-adaptation#8.2.3), [8.2.4](https://rcos.ecohubs.community/es/standard/core/0.1/layer-6-evolution-adaptation#8.2.4), [8.2.5](https://rcos.ecohubs.community/es/standard/core/0.1/layer-6-evolution-adaptation#8.2.5), [8.6.4](https://rcos.ecohubs.community/es/standard/core/0.1/layer-6-evolution-adaptation#8.6.4), [8.7.2](https://rcos.ecohubs.community/es/standard/core/0.1/layer-6-evolution-adaptation#8.7.2)*

```markdown
## <versión> — <Título breve>

- **Fecha de entrada en vigor:** <AAAA-MM-DD>
- **Registro de decisión:** <enlace al registro de decisión>
- **Tipo de decisión:** <Operativa / Estratégica / Constitucional>
- **Mecanismo:** <mecanismo de votación / autoridad delegada>
- **Resumen:** <una a tres frases describiendo qué cambió.>
- **Capas afectadas:** <p. ej. Capa 2, Capa 5>
- **Artefactos modificados:** <lista de artefactos>
- **Notas de migración:** <cualquier regla de transición; "ninguna" si no aplica>
```

---

## Versión Actual: v0.0 — Repositorio Inicializado

- **Fecha de entrada en vigor:** <AAAA-MM-DD>
- **Registro de decisión:** N/A — andamiaje inicial
- **Tipo de decisión:** N/A
- **Mecanismo:** N/A
- **Resumen:** Plantillas inicializadas. Todos los artefactos son plantillas — aún no se ha adoptado ninguna regla.
- **Capas afectadas:** Todas (solo andamiaje)
- **Artefactos modificados:** Todos los archivos creados como plantillas
- **Notas de migración:** Ninguna — estado inicial

---

_Las nuevas entradas se anteponen por encima de esta línea._
