**RCOS — Sistema Operativo de Comunidad Regenerativa**

# Registro de Invariantes

- **Generado:** 2026-11-06
- **Fuente (versión más reciente):** [https://rcos.ecohubs.community/es/articles/rcos-templates/layer-0/invariants-register](https://rcos.ecohubs.community/es/articles/rcos-templates/layer-0/invariants-register)
- **Todas las plantillas RCOS:** [https://rcos.ecohubs.community/es/articles/rcos-templates](https://rcos.ecohubs.community/es/articles/rcos-templates)

---
- **Capa:** 0 — Identidad y Alcance
- **Estado:** Plantilla — adaptar para tu comunidad
- **Referencia RCOS:** [§2.3](https://rcos.ecohubs.community/es/standard/core/0.1/layer-0-identity-scope#2.3), [§2.5](https://rcos.ecohubs.community/es/standard/core/0.1/layer-0-identity-scope#2.5)

> Las invariantes son restricciones que NO DEBEN ser violadas mientras estén en vigor. Ninguna decisión, rol, proceso o medida de emergencia puede anular una invariante. Si surge un conflicto entre una invariante y cualquier otra regla, la invariante prevalece.

---

## Invariantes Activas

*Cláusulas RCOS: [2.3.1](https://rcos.ecohubs.community/es/standard/core/0.1/layer-0-identity-scope#2.3.1), [2.3.2](https://rcos.ecohubs.community/es/standard/core/0.1/layer-0-identity-scope#2.3.2), [2.3.3](https://rcos.ecohubs.community/es/standard/core/0.1/layer-0-identity-scope#2.3.3), [2.3.4](https://rcos.ecohubs.community/es/standard/core/0.1/layer-0-identity-scope#2.3.4), [2.3.5](https://rcos.ecohubs.community/es/standard/core/0.1/layer-0-identity-scope#2.3.5), [2.3.6](https://rcos.ecohubs.community/es/standard/core/0.1/layer-0-identity-scope#2.3.6)*

| ID | Invariante | Añadida | Registro de decisión |
|---|---|---|---|
| INV-001 | _<Declaración de invariante, p. ej. El propósito principal nunca puede ser anulado por ninguna decisión operativa o estratégica, rol o medida de emergencia.>_ | <AAAA-MM-DD> | [enlace] |
| INV-002 | _<Declaración de invariante, p. ej. La autoridad siempre debe ser explícita y trazable al sistema de gobernanza — ninguna persona o rol puede poseer o ejercer autoridad no declarada.>_ | <AAAA-MM-DD> | [enlace] |
| INV-003 | _<Declaración de invariante, p. ej. La salida de la comunidad siempre debe ser posible y nunca puede ser bloqueada, penalizada ni condicionada más allá de lo definido en la Capa 1.>_ | <AAAA-MM-DD> | [enlace] |
| INV-004 | _<Declaración de invariante.>_ | <AAAA-MM-DD> | [enlace] |
| INV-005 | _<Declaración de invariante.>_ | <AAAA-MM-DD> | [enlace] |
| INV-006 | _<Declaración de invariante, p. ej. La seguridad física, psicológica e infantil siempre prevalece sobre los derechos de participación, la continuidad de roles y las preocupaciones reputacionales.>_ | <AAAA-MM-DD> | [enlace] |

---

## Registro de Ratificación

- **Adoptada:** <AAAA-MM-DD>
- **Tipo de decisión:** Constitucional
- **Versión:** <versión>
- **Registro de decisión:** <enlace al registro de decisión>
