**RCOS — Regenerative Community Operating System**

# Version History

- **Generated:** 2026-06-26
- **Source (latest version):** [https://rcos.ecohubs.community/articles/rcos-templates/layer-6/version-history](https://rcos.ecohubs.community/articles/rcos-templates/layer-6/version-history)
- **All RCOS templates:** [https://rcos.ecohubs.community/articles/rcos-templates](https://rcos.ecohubs.community/articles/rcos-templates)

---
- **Layer:** 6 — Evolution & Adaptation
- **Status:** Template — adapt for your community; updated with each adopted change
- **RCOS reference:** [§8.2](https://rcos.ecohubs.community/articles/rcos-core/v0-1/layer-6-evolution-adaptation#82-versioning-and-authority), [§8.6](https://rcos.ecohubs.community/articles/rcos-core/v0-1/layer-6-evolution-adaptation#86-artifacts)

> The authoritative human-readable record of all adopted changes to your community's RCOS implementation. The currently active version is the most recent entry at the top of this file. Superseded rules remain accessible via version control.

---

## Entry Format

*RCOS clauses: [8.2.1](https://rcos.ecohubs.community/articles/rcos-core/v0-1/layer-6-evolution-adaptation#82-versioning-and-authority), [8.2.2](https://rcos.ecohubs.community/articles/rcos-core/v0-1/layer-6-evolution-adaptation#82-versioning-and-authority), [8.2.3](https://rcos.ecohubs.community/articles/rcos-core/v0-1/layer-6-evolution-adaptation#82-versioning-and-authority), [8.2.4](https://rcos.ecohubs.community/articles/rcos-core/v0-1/layer-6-evolution-adaptation#82-versioning-and-authority), [8.2.5](https://rcos.ecohubs.community/articles/rcos-core/v0-1/layer-6-evolution-adaptation#82-versioning-and-authority), [8.6.4](https://rcos.ecohubs.community/articles/rcos-core/v0-1/layer-6-evolution-adaptation#86-artifacts), [8.7.2](https://rcos.ecohubs.community/articles/rcos-core/v0-1/layer-6-evolution-adaptation#87-layer-invariants)*

<details data-kind="rationale">
<summary>Why record every adopted change?</summary>

Governance that cannot point to "what changed, when, and why" is indistinguishable from governance by whoever speaks loudest. A single append-only ledger of adopted changes — with the superseded versions preserved in version control — makes the current state of the rules unambiguous and gives members, auditors, and future stewards a way to reconstruct the path that got us here.

</details>

<details data-kind="instructions">
<summary>How to fill this in</summary>

Use the entry template below for every adopted change. New entries are prepended above the most recent. Do not edit historical entries — corrections are recorded as new entries.

</details>

```markdown
## <version> — <Short title>

- **Effective date:** <YYYY-MM-DD>
- **Decision record:** <link to decision record>
- **Decision type:** <Operational / Strategic / Constitutional>
- **Mechanism:** <vote mechanism / delegated authority>
- **Summary:** <one to three sentences describing what changed.>
- **Layers affected:** <e.g. Layer 2, Layer 5>
- **Artifacts changed:** <list of artifacts>
- **Migration notes:** <any transition rules; "none" if not applicable>
```

---

## Current Version: v0.0 — Repository Initialized

- **Effective date:** <YYYY-MM-DD>
- **Decision record:** N/A — initial scaffold
- **Decision type:** N/A
- **Mechanism:** N/A
- **Summary:** Templates initialized. All artifacts are templates — no rules are yet adopted.
- **Layers affected:** All (scaffold only)
- **Artifacts changed:** All files created as templates
- **Migration notes:** None — initial state

---

_New entries are prepended above this line._
