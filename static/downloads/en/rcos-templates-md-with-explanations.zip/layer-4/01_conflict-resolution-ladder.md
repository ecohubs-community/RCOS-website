**RCOS — Regenerative Community Operating System**

# Conflict Resolution Ladder

- **Generated:** 2026-11-06
- **Source (latest version):** [https://rcos.ecohubs.community/articles/rcos-templates/layer-4/conflict-resolution-ladder](https://rcos.ecohubs.community/articles/rcos-templates/layer-4/conflict-resolution-ladder)
- **All RCOS templates:** [https://rcos.ecohubs.community/articles/rcos-templates](https://rcos.ecohubs.community/articles/rcos-templates)

---
- **Layer:** 4 — Conflict, Repair & Accountability
- **Status:** Template — adapt for your community
- **RCOS reference:** [§6.1](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.1), [§6.2](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.2), [§6.3](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.3), [§6.5](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.5)

> Gives every conflict a clear path, from direct conversation through facilitated dialogue and formal review up to a governance decision, with rules for non-response, deadlock, facilitators, and privacy along the way.

---

## Conflict Classification

*RCOS clauses: [6.1.1](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.1.1), [6.1.2](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.1.2), [6.1.3](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.1.3), [6.1.4](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.1.4), [6.1.5](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.1.5), [6.5.3](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.5.3), [6.6.4](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.6.4), [6.7.1](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.7.1)*

<details data-kind="rationale">
<summary>Why classify conflicts at all?</summary>

Without named classes, every dispute gets treated the same — or worse, treated differently based on who is involved. Explicit classes set the entry point, the response window, and the documentation burden up front, so safety-critical matters cannot be quietly routed through a friendly chat and minor friction cannot be weaponized into a formal review.

</details>

<details data-kind="instructions">
<summary>How to fill this in</summary>

For each class, set entry criteria, the entry step in the ladder, the initial response window, and the documentation burden.

</details>

| Class | Entry criteria | Entry point | Initial response window | Documentation |
|---|---|---|---|---|
| _<Interpersonal>_ | _<member-to-member friction>_ | _<Step 1>_ | _<window>_ | _<from which step>_ |
| _<Role-based>_ | _<role-performance dispute>_ | _<...>_ | _<...>_ | _<...>_ |
| _<Structural>_ | _<governance-process dispute>_ | _<...>_ | _<...>_ | _<...>_ |
| _<Ethical / obligation breach>_ | _<...>_ | _<...>_ | _<...>_ | _<...>_ |
| _<Safety-critical>_ | _<credible safety risk, coercion, abuse, or threats>_ | _<bypasses earlier steps>_ | _<short window>_ | _<from intake; immediate action permitted>_ |

> Safety-critical conflicts override participation rights, role continuity, and operational convenience.

## Resolution Ladder Steps

*RCOS clauses: [6.2.1](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.2.1), [6.2.2](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.2.2), [6.2.3](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.2.3), [6.2.4](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.2.4), [6.2.5](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.2.5), [6.5.3](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.5.3), [6.6.1](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.6.1)*

<details data-kind="rationale">
<summary>Why a stepped ladder instead of a single process?</summary>

Most conflict is low-stakes and best resolved between the people involved; forcing everything into formal review would kill trust and flood the governance system. A ladder matches process weight to dispute weight — private conversation first, facilitated dialogue next, written record only when needed, governance vote only when all else fails. It also makes escalation a structural right, not a favour granted by whoever holds social power.

</details>

<details data-kind="instructions">
<summary>How to fill this in</summary>

Define each ladder step: who is involved, what happens, the time window, and the escalation rule. Keep the early steps light and confidential; reserve formal review for later steps.

</details>

1. **Direct conversation** — _<parties attempt to resolve privately; window; outcome rules.>_
2. **Facilitated dialogue** — _<facilitator hosts conversation; confidentiality; window; outcome rules.>_
3. **Accountability intake** — _<formal written record opened; submissions; window; outcome rules.>_
4. **Accountability review** — _<structured review; both parties present; written recommendation; window; outcome rules.>_
5. **Governance decision** — _<minimum-necessary disclosure to Full Members; deliberation period; vote mechanism and threshold.>_
6. **Separation process** — _<coordinated with the Exit & Separation Protocol; minimum re-application block.>_

## Non-Response, Withdrawal, and Deadlock

*RCOS clauses: [6.2.5](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.2.5), [6.1.5](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.1.5)*

<details data-kind="rationale">
<summary>What stops a process from being killed by silence?</summary>

The easiest way to defeat any accountability process is to ignore it. If non-response, withdrawal, or deadlock leaves the matter frozen, the party on the receiving end of harm carries the cost of the inaction. Explicit rules for each failure mode convert silence into a documented escalation trigger rather than a veto.

</details>

<details data-kind="instructions">
<summary>How to fill this in</summary>

Define how non-response, mid-process withdrawal, deadlock, and procedural failure are handled. Each should have a documented escalation path.

</details>

**If a party does not respond within the defined window:**
- _<Follow-up notice; additional grace period; treatment of continued silence as non-resolution; escalation rule.>_

**If a party withdraws mid-process:**
- _<Notification of withdrawal; option for the other party to close or request a written summary; escalation rule for outstanding accountability matters.>_

**Deadlock (all resolution attempts exhausted):**
- _<Documentation of the deadlock; escalation to governance decision.>_

**Procedural failure review:**
- _<How procedural objections are raised; where they are logged; trigger for review of this artifact under the Change Protocol.>_

---

## Facilitator Selection and Replacement

*RCOS clauses: [6.3.1](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.3.1), [6.3.3](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.3.3)*

<details data-kind="rationale">
<summary>Why name how the Facilitator is chosen or replaced?</summary>

A facilitator who is implicated in the conflict — or socially aligned with one party — cannot hold the process fairly, no matter how good their intentions. Naming selection and replacement rules up front means the affected party does not have to fight for a neutral hearing while already under stress.

</details>

<details data-kind="instructions">
<summary>How to fill this in</summary>

State the default facilitator role, the rule when the facilitator is a party, the right to decline, and any provision for external facilitation.

</details>

- _<Default facilitator role per the Role Registry.>_
- _<Rule when the facilitator is a party — selection of a neutral substitute.>_
- _<Right of either party to decline a facilitator with stated conflict of interest.>_
- _<Optional external facilitation by mutual agreement.>_

## Privacy and Information Access Boundaries

*RCOS clauses: [6.5.3](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.5.3)*

<details data-kind="rationale">
<summary>Why bound information flow so tightly?</summary>

Conflict records contain the most sensitive material the community holds. Leaks, gossip, or casual disclosure cause second-order harm and deter future reporting. Explicit boundaries — what stays with the parties, what reaches Full Members, and when records are destroyed — make confidentiality enforceable rather than aspirational.

</details>

<details data-kind="instructions">
<summary>How to fill this in</summary>

State which steps are fully confidential, what minimum information may be disclosed at the governance step, the retention period, and the non-disclosure obligation.

</details>

- _<Steps 1–4: fully confidential; only parties and Facilitator may access records.>_
- _<Steps 5–6: minimum necessary information disclosed to Full Members; parties notified before disclosure. Define what "minimum necessary" means.>_
- _<Record retention: who holds records, for how long, then destroyed.>_
- _<Non-disclosure: no participant may share information about the process outside the defined participants without written consent of all parties.>_

## Safeguards

*RCOS clauses: [6.3.1](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.3.1), [6.3.2](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.3.2), [6.3.3](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.3.3), [6.3.4](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.3.4), [6.3.5](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.3.5), [6.6.2](https://rcos.ecohubs.community/standard/core/0.1/layer-4-conflict-repair-accountability#6.6.2)*

<details data-kind="rationale">
<summary>Why do safeguards exist on top of the ladder?</summary>

Process alone does not protect the party with less power. Retaliation, bad-faith complaints, conflicted facilitators, and unreviewed safety risks can all neutralize an otherwise good procedure. Safeguards are the backstops that keep the ladder functional when incentives push against honest reporting.

</details>

<details data-kind="instructions">
<summary>How to fill this in</summary>

For each safeguard, state the rule and the consequence when it is violated. Power-differential cases need their own intake channel.

</details>

- **Anti-retaliation:** _<retaliation against a member raising a conflict in good faith is itself grounds for an accountability process.>_
- **Bad-faith complaints:** _<deliberately false complaints may trigger an accountability process against the complainant.>_
- **Facilitator conflict of interest:** _<see Facilitator Selection and Replacement.>_
- **Process pause:** _<either party may pause once for up to X days by written notice.>_
- **Safety-critical immediate action:** _<facilitator may recommend a temporary access restriction pending review; review window.>_
- **Power differential — separate intake channel:** _<where a power differential exists, the affected member may submit intake directly to a body other than the standard Facilitator.>_
- **Role suspension during review:** _<Full Members may temporarily suspend a role holder's delegated authority during review without constituting forced exit.>_

---

## Ratification Record

- **Adopted:** <YYYY-MM-DD>
- **Decision type:** Strategic
- **Version:** <version>
- **Decision record:** <link to decision record>
